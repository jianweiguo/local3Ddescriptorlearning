# Caution

- You need to manually copy *libcompcur.dll* to the correct path to run the binary.

- When creating geometry images, GIGen will automatically skip existed geometry image files in the output directory. However, GIGen will **NOT** check the integrity of them. Therefore, it is the user's responsibility to make sure that all existed files are correct and integrated.